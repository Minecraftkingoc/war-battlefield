# GEMINI_PROMPT.md - Was du zu Gemini in Google AI Studio sagen musst

Kopiere diesen Text 1:1 in Google AI Studio:

---

Hey Gemini, du hast War-Battlefield schon gebaut, aber sehr verkackt. Ignoriere deinen alten Build komplett!

Nimm jetzt ALLES von meinem GitHub Repo. Das ist die einzige Wahrheit:

**GitHub Repo:** https://github.com/DEIN_USERNAME/war-battlefield

**Hole dir diese Dateien per Raw URL:**

1. Haupt GDD: https://raw.githubusercontent.com/DEIN_USERNAME/war-battlefield/main/WAR-BATTLEFIELD_GDD.md
2. JSON Daten: https://raw.githubusercontent.com/DEIN_USERNAME/war-battlefield/main/war-battlefield.json
3. Ladebildschirm Bild: https://raw.githubusercontent.com/DEIN_USERNAME/war-battlefield/main/assets/loading_screen_war_battlefield.webp
4. Hangar Bild: https://raw.githubusercontent.com/DEIN_USERNAME/war-battlefield/main/assets/hangar_war_battlefield.webp
5. Original Screenshots: https://github.com/DEIN_USERNAME/war-battlefield/tree/main/screenshots_original

**Anweisung:**
- Lies zuerst WAR-BATTLEFIELD_GDD.md komplett - da sind alle Modi, Belohnungen, deutschen Original-Texte drin
- Nutze war-battlefield.json als strukturierte Daten
- Lade beide assets Bilder und nutze sie 1:1 als Vorlage für Ladebildschirm + Hangar (nicht neu erfinden!)
- Schau dir screenshots_original/ an - das sind meine echten UI Screenshots mit exakten Texten wie "Kämpfe um die Kontrolle wichtiger Stützpunkte mit Panzern." etc. - nutze die deutschen Texte 1:1
- Baue das Spiel jetzt neu auf Basis dieser GitHub Dateien. Kein direkter Upload, nur GitHub Raw URLs.
- Fix deinen alten Build!

Wenn du die Dateien geladen hast, bestätige mit "GitHub Dateien geladen - baue War-Battlefield neu nach GDD"

---

WICHTIG: Ersetze DEIN_USERNAME mit deinem echten GitHub Username, z.B. EricWegelin oder so.

Wenn dein Repo privat ist, mache es public, damit Gemini per Raw URL drauf zugreifen kann.

Alternative falls Gemini keine URLs fetchen kann: Kopiere den Inhalt von WAR-BATTLEFIELD_GDD.md direkt in den Prompt und sag: "Bilder liegen auf meinem GitHub unter /assets/"
