# WAR-BATTLEFIELD - Komplette Datei für Gemini (Google AI Studio)

## ANWEISUNG FÜR GEMINI - Das musst du in AI Studio sagen:

```
Hey Gemini, du hast War-Battlefield schon gebaut, aber sehr verkackt. Hier ist die finale korrekte Datei von mir. Nimm diese Datei als einzige Wahrheit. Ignoriere deinen alten Build komplett und arbeite nur noch mit diesen Daten. Du musst das Spiel jetzt anhand dieser Daten neu aufbauen / fixen. Alle Modi, Belohnungen, Ladebildschirm, Hangar und Funktionen sind hier genau beschrieben mit meinen Original-Screenshots als Referenz. Nutze diese Datei und bau War-Battlefield richtig.

Hier ist die Datei:
[DATEI EINFÜGEN]
```

Dann die Datei unten dranhängen in AI Studio.

---

# 1. PROJEKT OVERVIEW
{'project': 'WAR-BATTLEFIELD', 'version': '1.0 - Fusion Build für Gemini', 'author': 'Eric Wegelin - Karlsdorf-Neuthard', 'engine_target': 'Unity / Unreal Engine 5 - Mobile + PC Crossplay', 'original_games': ['MWT: Tank Battles by Artstorm', 'Modern Warships by Artstorm'], 'description': 'Kombination aus MWT Tank Battles (Boden + Luft) + Modern Warships (See + Luft) zu einem einzigen Combined Arms Spiel. Land, See, Luft in EINEM Match.'}

Ziel: Ein Spiel wie in den Screenshots von Eric, aber alles in einem. Kein separates Spiel mehr.

## Artstyle
- MWT Neon-City: Miami Vice Sunset, lila/pink Lichter, nasse Straße reflektiert, Palmen, Graffiti, K-POP Festival Bühne mit Herz und LIVE SHOW
- Modern Warships: Realistischer Ocean, graue Kriegsschiffe feuern, Vulkan / Stadt Skyline, Rauch, Explosionen
- Fusion: Hafen als Übergang - Land (Kopfsteinpflaster mit Neon) trifft Wasser (Hafenbecken). Stadt Skyline im Hintergrund verbindet beides.
- UI: Dunkel, militärisch, oben Ressourcen Leiste (Gold, Silber, Dollar), unten Tabs, orange/roter ZUM GEFECHT Button, Artstorm + Vivox Footer, Version t0.24.5_a0.24.5.12034427

---

# 2. LADEBILDSCHIRM (Bereits generiert - Bild: image_20261007_204706.webp)
Komposition:
- Links: MWT Bild photo7410600777475755173 - Neon City, Panzer grün Camo in Mitte, weißer LKW mit Graffiti, B-2 Stealth Bomber oben, Palmen
- Rechts: MW Bild photo7824464227435558736 - Zerstörer 111 feuert breitseite, Wasser Spritzer, Vulkan raucht
- Mitte: Blend
- Top Center Logo: WAR BATTLEFIELD im weißen M-Logo Style wie MWT/MW
- Top Right: t0.24.5_a0.24.5.12034427
- Bottom: LASTANLAUF.... / SERVERDATEN WERDEN GELADEN.... + TIPP: APFSDS-Geschosse durchschlagen Panzerung besser aus großer Entfernung - setze sie gegen schwere Ziele ein!
- Bottom Logos: COMMUNICATIONS BY VIVOX + ARTSTORM

---

# 3. STARTBILDSCHIRM / HANGAR (Bereits generiert - Bild: image_20261007_185326.webp)
Referenz Bilder:
- MWT Hangar: photo4856687032085386741 - K-POP Festival Bühne lila, 2 Panzer mit weißen Sternen, TOS-1A, spezielle Angebote U3, T-55A Paket -99% 29min21sek, BEATMAKER -90%, ZSU-23-4M4 SHILKA -88%, Battle Pass 0/30, 0/16, ERIC WEGLIN 06Lvl
- MW Hangar: photo8636709927725274489 - RF Grad Sviyazhsk im Wasser, Stadt Skyline, ERIC WEGLIN 12, P Nicht aktiv, 364 Gold, 447,692 Dollar, Battle Pass 6t 6std Belohnung verfügbar, Anfänger-Dollartresor -94%

Fusion Hangar Details:
- Top Left Avatar ERIC WEGLIN Lvl 12 06Lvl
- Top Right Resources kombiniert: 899 Gold Stern + 364 Gold Barren + 643,290 Dollar + Mail + Settings + Korb
- Left Shop Vertical: Battle Pass 25t19std 6t6std Belohnung verfügbar 0/30, K-POP FESTIVAL Event 01t19std, TOS-1A LIEFERUNGEN 22t19std, SPEZIELLE ANGEBOTE U3 12t19std
- Right Shop Vertical: Anfänger-Dollartresor -94% 1/1, +50 +100,000 +5 +1, T-55A PAKET SPEZIAL -98% 29min21sek, BEATMAKER SPEZIAL -90% 25min21sek, ZSU-23-4M4 SHILKA SPEZIAL -88% 14min21sek
- Center: Zwei Panzer links auf K-POP Tanzboden lila leuchtend, ein Panzer weiter hinten, Warship rechts im Wasser an Kaimauer
- Bottom Center Button: ZUM GEFECHT! / WAR-BATTLEFIELD EROBERUNG rot-orange mit gekreuzten Kanonen + Schiff Icon
- Bottom Tabs: SCHIFFE / PANZER / HANGAR (aktiv orange) / MARKT / CLAN
- Chat: [ATUC] TheProphet200: ok. NEW Tag

---

# 4. ALLE BEKANNTEN MODI - Original Screenshots 1:1

## 4.1 Modern Warships Primär (photo7502948119885242434.jpeg / photo7502948119885242434_33cb1a.jpeg)
UI: Zurück | SPIELMODI // PRIMÄR, Tabs Primär | Clan-Kriege | Ranglistenmodus | Benutzerdefiniert, AUSGEWÄHLTE SPIELMODI 1/4, ALLE AUSWÄHLEN Checkbox grün, ONLINE/OFFLINE Toggle (OFFLINE rot aktiv), Zum GEFECHT! Button rot

Karten:
- TEAM-DEATHMATCH: Bild brennendes Schiff auf See, Würfel Icon oben, Kartenauswahl (15/15) + Pfeil Icon, grüner Haken oben rechts, i Info Button
- DEATHMATCH: Schloss Icon, LEVEL ERFORDERLICH 16, dunkel
- VORHERRSCHAFT: A B C Icon, Schloss, LEVEL ERFORDERLICH 13
- LUFTKAMPF: Flugzeug Icon, Text Zugelassene Klassen Flugzeugträger Angriffsflugzeugträger, Schloss LEVEL ERFORDERLICH 16

War-Battlefield Umsetzung: Alle 4 Modi bleiben, aber Karten sind jetzt Küstenkarten wo Panzer + Schiffe gemeinsam spawnen. Offline = nur Bots.

## 4.2 MWT Tank Battles (photo1598734657972458524.jpeg / photo3076962432899957573.jpeg)
UI: <- SPIELMODI, 5 Karten horizontal, ZUM GEFECHT orange unten

- LUFT-TEAM-DEATHMATCH: Grau disabled, 10 LEVEL rot Banner, Text: Ein Luftkampf zwischen zwei Teams. Schalte deine Gegner aus, manövriere geschickt und gewinne diesen spannenden Luftkampf.
- PANZER EROBERUNG: A C B Icon groß weiß, Text: Kämpfe um die Kontrolle wichtiger Stützpunkte mit Panzern., unten rote Icons mit X (keine Infanterie etc) + i
- EROBERUNG: A C B, Text: Ein Kampf um die Kontrolle der wichtigsten Punkte unter Einsatz aller Arten von technischen Mitteln. -> DAS IST HAUPTMODUS für War-Battlefield!
- KAMPF MIT KI: AI Icon weiß im Gehirn, Text: Es nehmen ausschließlich Bots am Spiel teil. Es werden nur Belohnungen für den Kampf vergeben, Turnierbelohnungen sind deaktiviert.
- BENUTZERDEFINIERTES SPIEL: Controller Icon, Text: Erstelle deine eigenen Schlachten und spiele mit Freunden.

War-Battlefield: EROBERUNG wird zu KÜSTEN-EROBERUNG - A in Stadt (Panzer), B am Strand (Panzer+Schiff), C im Hafen (Schiff dominiert aber Panzer können von Land schießen)

## 4.3 Clan-Kriege (photo8367484895772330727.jpeg)
Grüner rauchiger Hintergrund, Tab Clan-Kriege aktiv grün unterstrichen, goldenes Clan Abzeichen mit Glocke, Text: Tritt einem Clan bei, um an Clan-Gefechten teilzunehmen und wertvolle Belohnungen zu erhalten, Button: Clan suchen blau

Fusion: Clan Map ist Weltkarte, Clans erobern Häfen + Städte. Belohnung Clan-Währung für exklusive Fahrzeuge.

## 4.4 Ranglistenmodus (photo1967039798983863284.jpeg)
Grüner Hintergrund, Tab Ranglistenmodus aktiv, gelbes ! Icon, Text gelb: Ranglistenmodus wird auf Level 23 freigeschaltet, weiß: Spiele, steige in der Marineakademie auf, verbessere deine Schiffe, um im Ranglistenmodus zu kämpfen.

Fusion: Ab Level 23, Season 1 Monat, Ränge Bronze Silber Gold Platin Diamant je 3 Sub-Tiers 200 Punkte, Bonus Schiffstypen pro Woche +15 mal Bonus, Belohnung Rank Season Coins + Rank Battle Coins für Rank Shop.

## 4.5 Benutzerdefiniert (photo1971143025107784278.jpeg)
Grüner Hintergrund, Tab Benutzerdefiniert aktiv, nur eine Karte: TEAM-DEATHMATCH Bild brennendes Schiff

Fusion: Custom Lobby mit 4-stelligem Code, Map Wahl, Tier Limit, Premium erlaubt ja/nein, Tournament Modus mit Captain setzt Spawns, Modus fest Team-Deathmatch.

## 4.6 Squad (photo1442900785045539099.jpeg / photo253468997312088964.jpeg)
UI: <- Zurück SQUAD, Squad Liste links 12 ERIC WEGLIN RF Grad Sviyazhsk Avatar Mann, Tabs Alle (blau aktiv) | Freunde | Clan, rechts Liste 17 NICO SUTHOFF OFFLINE Captain Avatar, Unten Squad verlassen rot

Zweiter Screen Clan Tab aktiv blau: Text Du bist kein Mitglied eines Clans. Suchen Button blau

Fusion: Squad max 4, du + Nico, spawn zusammen, shared XP + voice chat, einer fährt Panzer/Schiff einer bedient Waffen (CIWS/Raketen). Clan suchen führt zu Clan Browser.

---

# 5. BELOHNUNGEN & PROGRESSION

## Starter (aus früheren Screenshots)
- 100,000 DOLLAR - Das Inventar wurde aktualisiert! FORTFAHREN, blau/roter Rauch
- 400 MK1 UPGRADE U1 grün
- 2x MK3 UPGRADE U3 lila + 50 ERFAHRUNG Gold Stern
- Sonderlieferung Hilfe für den angehenden Kommandanten! Melde dich jeden Tag an... Endet in 14t 18 std, Woche 1-4 Tabs
TAG1 50 Upgrade Chip check grün, TAG2 1T Gold check, TAG3 25 Adler Emblem gelb aktiv EINSAMMELN, TAG4 1T, TAG5 750,000 Dollar, TAG6 50 UP, TAG7 7T Premium + P Krone groß

War-Battlefield Starter: 100k + 400 MK1 + 2 MK3 + 50 XP reicht für T-55A + RF Grad Sviyazhsk Tier1. Tagesbelohnung Woche1 Boden, Woche2 See, Woche3 Luft, Woche4 Legendär.

## Economy
Dollar = Hauptwährung, Gold = Premium (T), Upgrade Chips MK1/MK2/MK3, Erfahrung Stern, Globus 25 = Nation Unlock

---

# 6. GAMEPLAY MECHANICS FUSION

MWT Mechanics (aus Websuche):
- Third-Person Echtzeit, Reload Times, Armor Angling, Terrain Line of Sight, zerstörbare Umgebung, Combined Arms: Panzer, Flugabwehr, SPG, MLRS, Drohnen, Fighter, Heli in einem Match

MW Mechanics:
- Tier System ohne Tech-Tree, Weapon Swapping über Nationen (US Schiff mit RU Waffen etc), Missile POV, CIWS mit Magazin und Nachladen, detaillierte Stats: initial speed, max speed, acceleration, lock-on speed, firing penalty, 10 Min Match Timer, 5v5, Ticketsystem 500

Fusion Mechanic Theater-Switch:
Spieler hat Loadout: Slot1 Panzer, Slot2 Schiff, Slot3 Luft. Im Match an Supply Zone wechseln. Wenn Panzer zerstört, respawn als Drohne oder im Schiff wenn in Eroberung Modus (3 Leben + 5 Sek Respawn + Invincibility Shield). Team Deathmatch kein Respawn.

---

# 7. DATEIEN FÜR GEMINI

Bilder die Eric hochgeladen hat und die du als Referenz nutzen MUSST:
- Alle /mnt/data/photo*.jpeg - das sind echte UI Screenshots
- Generierte Bilder: /mnt/data/gallery/image_20261007_204706.webp (Ladebildschirm) + /mnt/data/gallery/image_20261007_185326.webp (Hangar)

Nutze diese Bilder als UI Vorlage, nicht erfinden!

---

# 8. ANFORDERUNG AN GEMINI - WAS DU JETZT BAUEN MUSST

1. Nimm diese GDD und baue das Hauptmenü neu - exakt wie im Hangar Bild beschrieben
2. Baue den Ladebildschirm exakt wie im Ladebildschirm Bild
3. Implementiere alle 5+4 Modi mit Level Gates 10/13/16/23
4. Implementiere Squad System mit Eric + Nico
5. Implementiere Sonderlieferung 7 Tage mit den originalen Belohnungen
6. Implementiere Theater-Switch Mechanic
7. Nutze die originalen deutschen Texte 1:1, keine Übersetzung!
8. Mache es Mobile + PC Crossplay wie Modern Warships (Android, iOS, Windows)
9. Fix deinen alten verkackten Build - dieser hier ist die Wahrheit

Viel Erfolg, Gemini. Mach es richtig diesmal.

