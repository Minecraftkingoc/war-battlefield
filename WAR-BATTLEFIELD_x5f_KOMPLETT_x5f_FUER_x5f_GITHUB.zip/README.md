# WAR-BATTLEFIELD - Fusion Game for Gemini

> Kombiniertes Spiel aus MWT: Tank Battles + Modern Warships - Finaler Build für Google AI Studio

## Für Gemini in Google AI Studio:

**Nimm alles von meinem GitHub, nicht aus deinem alten Build!**

Dieses Repo ist die einzige Wahrheit. Lade alle Dateien per raw.githubusercontent.com.

## Struktur:
- `WAR-BATTLEFIELD_GDD.md` - Komplette Game Design Document mit allen Modi, Belohnungen, Texten
- `war-battlefield.json` - Strukturierte Daten für AI Studio
- `assets/loading_screen_war_battlefield.webp` - Neuer kombinierter Ladebildschirm (Neon-City + Warship)
- `assets/hangar_war_battlefield.webp` - Neuer kombinierter Hangar (K-POP Festival + Hafen + Eric + Nico)
- `screenshots_original/` - Alle 9 Original Screenshots als UI Referenz

## Original Modi (aus Screenshots):
MWT: LUFT-TEAM-DEATHMATCH 10 LEVEL, PANZER EROBERUNG A/B/C, EROBERUNG A/B/C, KAMPF MIT KI (nur Bots), BENUTZERDEFINIERTES SPIEL
MW: TEAM-DEATHMATCH 15/15, DEATHMATCH LEVEL 16, VORHERRSCHAFT LEVEL 13, LUFTKAMPF LEVEL 16, CLAN-KRIEGE, RANGLISTENMODUS LEVEL 23, BENUTZERDEFINIERT, SQUAD ERIC WEGLIN + NICO SUTHOFF

## Original Belohnungen:
100,000 DOLLAR, 400 MK1, 2x MK3 + 50 XP, Sonderlieferung TAG1 50, TAG2 1T, TAG3 25, TAG4 1T, TAG5 750k, TAG6 50, TAG7 7T Premium

## Für Eric - Wie pushen:
1. Neues Repo auf GitHub erstellen: war-battlefield
2. Diesen Ordner komplett hochladen
3. In AI Studio dann Raw URLs nutzen (siehe GEMINI_PROMPT.md)
